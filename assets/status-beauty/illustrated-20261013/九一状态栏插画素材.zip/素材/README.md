# 九一状态栏插画素材

这套素材用于 12 花间读者札、13 橄榄票根簿、14 猫兔夜话、15 兔子计划跑道。09 使用角色头像制作双色海报，不需要新增插画。02、03、20 未在本次素材范围内。

制作日期：2026-10-13。署名：九一。

## 文件与处理

| 文件 | 用途 | PNG 尺寸 | 背景 |
| --- | --- | --- | --- |
| 12-main.png | 工笔花鸟封面主图，左侧留白用于页面排版 | 1200 × 1600 | 宣纸底 |
| 12-sprig.png | 札记角落的海棠小枝 | 800 × 800 | 透明 |
| 12-paper.png | 暖白灰绿宣纸底纹 | 1024 × 1024 | 不透明 |
| 13-olive.png | 橄榄复古旅行主题的枝叶插画 | 1200 × 1200 | 透明 |
| 13-labels.png | 四枚空白行李标签，文字由界面叠加 | 1200 × 1200 | 透明 |
| 14-pets.png | 黑猫与白兔的 Y2K 主贴纸 | 1024 × 1024 | 透明 |
| 14-flowers.png | 五枚绿色、薄荷色及银色花朵贴纸 | 1024 × 1024 | 透明 |
| 14-clouds.png | 云朵与四角闪光贴纸 | 1024 × 1024 | 透明 |
| 15-astrolabe.png | 金青水彩星盘封面 | 1600 × 1600 | 水彩纸底 |
| 15-paper.png | 暖奶油色水彩纸底纹 | 1024 × 1024 | 不透明 |

素材由 OpenAI 图像生成工具 `image_gen.imagegen` 生成。下面保留用户提供的原始英文提示词，便于后续复用；实际生成同时遵循用户关于尺寸、透明背景、无文字、无水印的说明。PNG 是按指定尺寸重采样后的交付版，WebP 是对应的网页压缩版。

处理工具：Pillow。处理仅包括等比例 LANCZOS 重采样、PNG 无损编码与 WebP quality 90 编码，没有抠图、重绘、内容裁切或增加图像元素。透明素材保留原 alpha 通道。详细尺寸、透明像素比例、压缩大小与纸纹边缘差异见包内 `asset-quality-report.json`。

两张纸纹按可平铺用途生成；生成结果不是像素严格无缝纹理，使用时应检查实际铺底效果。贴纸白边、空行李标签装饰边来自各自的特定提示词，不是附加的画面外框。

## 12 花间读者札

### 12-main.png — 新中式工笔花鸟主图

灰绿小鸟停在白玉兰与浅色海棠枝上，宣纸肌理，枝条从右上进入；左侧保留大面积留白，供真实页面标题与文字使用。

```text
Traditional Chinese gongbi bird-and-flower painting on aged rice paper, a single slender branch of white magnolia and pale begonia entering from the upper right, one small grey-green bird perched on the branch, delicate fine ink outlines, soft mineral pigments, muted palette of sage grey-green, celadon, warm ivory and faint ink black, large empty negative space on the left half, subtle paper fibers and light foxing, elegant, quiet, museum scan quality, no text, no seal, no border
```

### 12-sprig.png — 海棠角落小枝

透明背景，两片叶与一枚花苞，灰绿与象牙白淡彩，适合小尺寸角饰。

```text
A small isolated sprig of gongbi-style begonia with two leaves and one bud, fine ink line and soft sage-green and ivory wash, Chinese meticulous painting style, centered, transparent background, no text, no shadow
```

### 12-paper.png — 宣纸底纹

暖象牙白中带很淡的灰绿调，保留细长纤维与自然纸纹，不含物体或文字。

```text
Seamless tileable texture of handmade Chinese xuan rice paper, warm ivory with very faint grey-green tint, visible long fibers and subtle uneven absorbency, flat even lighting, no objects, no text
```

## 13 橄榄票根簿

### 13-olive.png — 橄榄枝铜版画

透明背景，深橄榄绿铜版排线植物插画，用于复古旅行票根主题。

```text
Vintage copperplate engraving of an olive branch with leaves and a few olives, fine cross-hatching, deep olive green ink on transparent background, botanical illustration style from an 1890s travel guide, no text
```

### 13-labels.png — 复古行李标签

四枚带旧纸边缘与褪色印刷质感的空白标签，主体分开排列；中间不写文字，供页面添加真实内容。

```text
Set of 4 blank vintage luggage labels and travel stamps, olive green, mustard and cream, worn paper edges, faded print texture, ornate borders but completely blank centers, scattered layout with spacing, transparent background, no text, no letters
```

## 14 猫兔夜话

### 14-pets.png — 猫兔贴纸

黑猫与白兔背靠背坐着，Y2K 亮面与银色金属高光，搭配青柠绿点缀及白色贴纸描边。

```text
Y2K glossy sticker of a small black cat and a white rabbit sitting back to back, chunky white sticker outline, shiny chrome highlights, early-2000s web graphic style, lime green and silver accents, transparent background, no text
```

### 14-flowers.png — 花朵贴纸

五枚雏菊与星形花，银铬、半透明果冻塑料质感，贴纸之间留出间隔。

```text
Set of 5 glossy Y2K daisy and star-flower stickers, chrome and translucent jelly plastic look, lime green, mint, white and silver, thick white die-cut outlines, scattered layout with spacing between each, transparent background, no text
```

### 14-clouds.png — 云朵和闪光

Y2K 网页感的白色云朵与四角星，轻微青柠绿发光，透明背景。

```text
Set of puffy pixel-art clouds and four-point sparkle stars in Y2K web style, white with soft lime-green glow, slightly glossy, scattered with spacing, transparent background, no text
```

## 15 兔子计划跑道

### 15-astrolabe.png — 金青水彩星盘

金色细线星盘叠在青绿色水彩晕染上，带环形刻度、月相、小星星及外环奔跑兔子，边缘保留空气感。

```text
Ornate astrolabe and celestial chart drawn in fine metallic gold line art over loose teal and deep turquoise watercolor washes, concentric rings, zodiac-like tick marks without letters, small stars and moon phases, a tiny running rabbit silhouette on the outer ring, cream watercolor paper texture, airy white space around the edges, elegant, hand-painted, no text, no numbers
```

### 15-paper.png — 水彩纸底

暖奶油色冷压水彩纸，自然颗粒与很淡的青色颜料纹理，用作低对比阅读底纹。

```text
Seamless tileable cold-press watercolor paper texture, warm cream, faint teal pigment blooms near nothing, soft natural grain, flat lighting, no objects, no text
```

## 生成来源文件记录

| 交付名称 | 图像生成工具返回文件 |
| --- | --- |
| 12-main | exec-26cb3ecb-17a6-4890-922a-4038dee19f25.png |
| 12-sprig | exec-e0446c2c-a8b9-4a01-8117-91087acf94bd.png |
| 12-paper | exec-931ff403-97f9-47e9-9ae1-ca2ce7deac4a.png |
| 13-olive | exec-27b60edb-9ff4-4757-964a-7c51e8d67223.png |
| 13-labels | exec-112f1e09-2d8a-4945-a584-07395cc5e763.png |
| 14-pets | exec-032b6c3c-1342-4ae6-af0f-a069db8f2413.png |
| 14-flowers | exec-3fb253a5-a038-4593-9065-acd441a78b06.png |
| 14-clouds | exec-e3146efc-fc7a-4435-95b2-40810af9c211.png |
| 15-astrolabe | exec-41b02a38-0966-4bbb-a2a1-c124da87ae7c.png |
| 15-paper | exec-728037cf-9bbc-4099-9118-285b5ab6aca1.png |
